#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private TachEon.TachEonOrion[] cacheTachEonOrion;

		
		public TachEon.TachEonOrion TachEonOrion(int numberOfPastLevelsToLoad, bool inverseSignals, Brush aColor, DashStyleHelper aLineStyle, int aLineSize, eFluxOrionLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush dotAColor, DashStyleHelper dotALineStyle, int dotALineSize, int dotALineLength, Brush pColor, DashStyleHelper pLineStyle, int pLineSize, eFluxOrionLineLength pLineExtMethod, int pLineLength, int pDotOffset, Brush dotPColor, DashStyleHelper dotPLineStyle, int dotPLineSize, int dotPLineLength, TextPositionTachEon textLocation, int textDisplayCount)
		{
			return TachEonOrion(Input, numberOfPastLevelsToLoad, inverseSignals, aColor, aLineStyle, aLineSize, aLineExtMethod, aLineLength, aDotOffset, dotAColor, dotALineStyle, dotALineSize, dotALineLength, pColor, pLineStyle, pLineSize, pLineExtMethod, pLineLength, pDotOffset, dotPColor, dotPLineStyle, dotPLineSize, dotPLineLength, textLocation, textDisplayCount);
		}


		
		public TachEon.TachEonOrion TachEonOrion(ISeries<double> input, int numberOfPastLevelsToLoad, bool inverseSignals, Brush aColor, DashStyleHelper aLineStyle, int aLineSize, eFluxOrionLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush dotAColor, DashStyleHelper dotALineStyle, int dotALineSize, int dotALineLength, Brush pColor, DashStyleHelper pLineStyle, int pLineSize, eFluxOrionLineLength pLineExtMethod, int pLineLength, int pDotOffset, Brush dotPColor, DashStyleHelper dotPLineStyle, int dotPLineSize, int dotPLineLength, TextPositionTachEon textLocation, int textDisplayCount)
		{
			if (cacheTachEonOrion != null)
				for (int idx = 0; idx < cacheTachEonOrion.Length; idx++)
					if (cacheTachEonOrion[idx].NumberOfPastLevelsToLoad == numberOfPastLevelsToLoad && cacheTachEonOrion[idx].InverseSignals == inverseSignals && cacheTachEonOrion[idx].AColor == aColor && cacheTachEonOrion[idx].ALineStyle == aLineStyle && cacheTachEonOrion[idx].ALineSize == aLineSize && cacheTachEonOrion[idx].ALineExtMethod == aLineExtMethod && cacheTachEonOrion[idx].ALineLength == aLineLength && cacheTachEonOrion[idx].ADotOffset == aDotOffset && cacheTachEonOrion[idx].DotAColor == dotAColor && cacheTachEonOrion[idx].DotALineStyle == dotALineStyle && cacheTachEonOrion[idx].DotALineSize == dotALineSize && cacheTachEonOrion[idx].DotALineLength == dotALineLength && cacheTachEonOrion[idx].PColor == pColor && cacheTachEonOrion[idx].PLineStyle == pLineStyle && cacheTachEonOrion[idx].PLineSize == pLineSize && cacheTachEonOrion[idx].PLineExtMethod == pLineExtMethod && cacheTachEonOrion[idx].PLineLength == pLineLength && cacheTachEonOrion[idx].PDotOffset == pDotOffset && cacheTachEonOrion[idx].DotPColor == dotPColor && cacheTachEonOrion[idx].DotPLineStyle == dotPLineStyle && cacheTachEonOrion[idx].DotPLineSize == dotPLineSize && cacheTachEonOrion[idx].DotPLineLength == dotPLineLength && cacheTachEonOrion[idx].TextLocation == textLocation && cacheTachEonOrion[idx].TextDisplayCount == textDisplayCount && cacheTachEonOrion[idx].EqualsInput(input))
						return cacheTachEonOrion[idx];
			return CacheIndicator<TachEon.TachEonOrion>(new TachEon.TachEonOrion(){ NumberOfPastLevelsToLoad = numberOfPastLevelsToLoad, InverseSignals = inverseSignals, AColor = aColor, ALineStyle = aLineStyle, ALineSize = aLineSize, ALineExtMethod = aLineExtMethod, ALineLength = aLineLength, ADotOffset = aDotOffset, DotAColor = dotAColor, DotALineStyle = dotALineStyle, DotALineSize = dotALineSize, DotALineLength = dotALineLength, PColor = pColor, PLineStyle = pLineStyle, PLineSize = pLineSize, PLineExtMethod = pLineExtMethod, PLineLength = pLineLength, PDotOffset = pDotOffset, DotPColor = dotPColor, DotPLineStyle = dotPLineStyle, DotPLineSize = dotPLineSize, DotPLineLength = dotPLineLength, TextLocation = textLocation, TextDisplayCount = textDisplayCount }, input, ref cacheTachEonOrion);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.TachEon.TachEonOrion TachEonOrion(int numberOfPastLevelsToLoad, bool inverseSignals, Brush aColor, DashStyleHelper aLineStyle, int aLineSize, eFluxOrionLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush dotAColor, DashStyleHelper dotALineStyle, int dotALineSize, int dotALineLength, Brush pColor, DashStyleHelper pLineStyle, int pLineSize, eFluxOrionLineLength pLineExtMethod, int pLineLength, int pDotOffset, Brush dotPColor, DashStyleHelper dotPLineStyle, int dotPLineSize, int dotPLineLength, TextPositionTachEon textLocation, int textDisplayCount)
		{
			return indicator.TachEonOrion(Input, numberOfPastLevelsToLoad, inverseSignals, aColor, aLineStyle, aLineSize, aLineExtMethod, aLineLength, aDotOffset, dotAColor, dotALineStyle, dotALineSize, dotALineLength, pColor, pLineStyle, pLineSize, pLineExtMethod, pLineLength, pDotOffset, dotPColor, dotPLineStyle, dotPLineSize, dotPLineLength, textLocation, textDisplayCount);
		}


		
		public Indicators.TachEon.TachEonOrion TachEonOrion(ISeries<double> input , int numberOfPastLevelsToLoad, bool inverseSignals, Brush aColor, DashStyleHelper aLineStyle, int aLineSize, eFluxOrionLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush dotAColor, DashStyleHelper dotALineStyle, int dotALineSize, int dotALineLength, Brush pColor, DashStyleHelper pLineStyle, int pLineSize, eFluxOrionLineLength pLineExtMethod, int pLineLength, int pDotOffset, Brush dotPColor, DashStyleHelper dotPLineStyle, int dotPLineSize, int dotPLineLength, TextPositionTachEon textLocation, int textDisplayCount)
		{
			return indicator.TachEonOrion(input, numberOfPastLevelsToLoad, inverseSignals, aColor, aLineStyle, aLineSize, aLineExtMethod, aLineLength, aDotOffset, dotAColor, dotALineStyle, dotALineSize, dotALineLength, pColor, pLineStyle, pLineSize, pLineExtMethod, pLineLength, pDotOffset, dotPColor, dotPLineStyle, dotPLineSize, dotPLineLength, textLocation, textDisplayCount);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.TachEon.TachEonOrion TachEonOrion(int numberOfPastLevelsToLoad, bool inverseSignals, Brush aColor, DashStyleHelper aLineStyle, int aLineSize, eFluxOrionLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush dotAColor, DashStyleHelper dotALineStyle, int dotALineSize, int dotALineLength, Brush pColor, DashStyleHelper pLineStyle, int pLineSize, eFluxOrionLineLength pLineExtMethod, int pLineLength, int pDotOffset, Brush dotPColor, DashStyleHelper dotPLineStyle, int dotPLineSize, int dotPLineLength, TextPositionTachEon textLocation, int textDisplayCount)
		{
			return indicator.TachEonOrion(Input, numberOfPastLevelsToLoad, inverseSignals, aColor, aLineStyle, aLineSize, aLineExtMethod, aLineLength, aDotOffset, dotAColor, dotALineStyle, dotALineSize, dotALineLength, pColor, pLineStyle, pLineSize, pLineExtMethod, pLineLength, pDotOffset, dotPColor, dotPLineStyle, dotPLineSize, dotPLineLength, textLocation, textDisplayCount);
		}


		
		public Indicators.TachEon.TachEonOrion TachEonOrion(ISeries<double> input , int numberOfPastLevelsToLoad, bool inverseSignals, Brush aColor, DashStyleHelper aLineStyle, int aLineSize, eFluxOrionLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush dotAColor, DashStyleHelper dotALineStyle, int dotALineSize, int dotALineLength, Brush pColor, DashStyleHelper pLineStyle, int pLineSize, eFluxOrionLineLength pLineExtMethod, int pLineLength, int pDotOffset, Brush dotPColor, DashStyleHelper dotPLineStyle, int dotPLineSize, int dotPLineLength, TextPositionTachEon textLocation, int textDisplayCount)
		{
			return indicator.TachEonOrion(input, numberOfPastLevelsToLoad, inverseSignals, aColor, aLineStyle, aLineSize, aLineExtMethod, aLineLength, aDotOffset, dotAColor, dotALineStyle, dotALineSize, dotALineLength, pColor, pLineStyle, pLineSize, pLineExtMethod, pLineLength, pDotOffset, dotPColor, dotPLineStyle, dotPLineSize, dotPLineLength, textLocation, textDisplayCount);
		}

	}
}

#endregion
