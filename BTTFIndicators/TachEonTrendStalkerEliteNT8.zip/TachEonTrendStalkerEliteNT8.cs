#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private TachEon.TachEonTrendStaker[] cacheTachEonTrendStaker;

		
		public TachEon.TachEonTrendStaker TachEonTrendStaker(string sAggressiveTrendMode, int nAgressivePeriod, double dAggressiveMultiplier, int nAggressiveSmoothingPeriod, string sAggressiveTouchedWAV, string sResumeTrendWAV, string sTrendReversalDownWAV, string sTrendstalkerReversalUpWAV, string sTrendMode, int nPeriod, double dMultiplier, int nSmoothingPeriod, bool bRoundToTick, bool bColorBars, Brush pUpColor, Brush pDownColor, double dAutoIncrement, double dT1Mult, double dT2Mult, double dT3Mult, double dT4Mult, double dT5Mult, double dT6Mult, bool bViewHistoricalTargets, bool bViewCurrentTargets, bool bViewTargetLabels, bool bArrowsOnReversal, bool bShowVerticalLine, Brush pVLineColor, DashStyleHelper pVLineStyle, int nVLineWidth, bool bSearch, bool bMonday, bool bTuesday, bool bWednesday, bool bThursday, bool bFriday)
		{
			return TachEonTrendStaker(Input, sAggressiveTrendMode, nAgressivePeriod, dAggressiveMultiplier, nAggressiveSmoothingPeriod, sAggressiveTouchedWAV, sResumeTrendWAV, sTrendReversalDownWAV, sTrendstalkerReversalUpWAV, sTrendMode, nPeriod, dMultiplier, nSmoothingPeriod, bRoundToTick, bColorBars, pUpColor, pDownColor, dAutoIncrement, dT1Mult, dT2Mult, dT3Mult, dT4Mult, dT5Mult, dT6Mult, bViewHistoricalTargets, bViewCurrentTargets, bViewTargetLabels, bArrowsOnReversal, bShowVerticalLine, pVLineColor, pVLineStyle, nVLineWidth, bSearch, bMonday, bTuesday, bWednesday, bThursday, bFriday);
		}


		
		public TachEon.TachEonTrendStaker TachEonTrendStaker(ISeries<double> input, string sAggressiveTrendMode, int nAgressivePeriod, double dAggressiveMultiplier, int nAggressiveSmoothingPeriod, string sAggressiveTouchedWAV, string sResumeTrendWAV, string sTrendReversalDownWAV, string sTrendstalkerReversalUpWAV, string sTrendMode, int nPeriod, double dMultiplier, int nSmoothingPeriod, bool bRoundToTick, bool bColorBars, Brush pUpColor, Brush pDownColor, double dAutoIncrement, double dT1Mult, double dT2Mult, double dT3Mult, double dT4Mult, double dT5Mult, double dT6Mult, bool bViewHistoricalTargets, bool bViewCurrentTargets, bool bViewTargetLabels, bool bArrowsOnReversal, bool bShowVerticalLine, Brush pVLineColor, DashStyleHelper pVLineStyle, int nVLineWidth, bool bSearch, bool bMonday, bool bTuesday, bool bWednesday, bool bThursday, bool bFriday)
		{
			if (cacheTachEonTrendStaker != null)
				for (int idx = 0; idx < cacheTachEonTrendStaker.Length; idx++)
					if (cacheTachEonTrendStaker[idx].SAggressiveTrendMode == sAggressiveTrendMode && cacheTachEonTrendStaker[idx].NAgressivePeriod == nAgressivePeriod && cacheTachEonTrendStaker[idx].DAggressiveMultiplier == dAggressiveMultiplier && cacheTachEonTrendStaker[idx].NAggressiveSmoothingPeriod == nAggressiveSmoothingPeriod && cacheTachEonTrendStaker[idx].SAggressiveTouchedWAV == sAggressiveTouchedWAV && cacheTachEonTrendStaker[idx].SResumeTrendWAV == sResumeTrendWAV && cacheTachEonTrendStaker[idx].STrendReversalDownWAV == sTrendReversalDownWAV && cacheTachEonTrendStaker[idx].STrendstalkerReversalUpWAV == sTrendstalkerReversalUpWAV && cacheTachEonTrendStaker[idx].STrendMode == sTrendMode && cacheTachEonTrendStaker[idx].NPeriod == nPeriod && cacheTachEonTrendStaker[idx].DMultiplier == dMultiplier && cacheTachEonTrendStaker[idx].NSmoothingPeriod == nSmoothingPeriod && cacheTachEonTrendStaker[idx].BRoundToTick == bRoundToTick && cacheTachEonTrendStaker[idx].BColorBars == bColorBars && cacheTachEonTrendStaker[idx].PUpColor == pUpColor && cacheTachEonTrendStaker[idx].PDownColor == pDownColor && cacheTachEonTrendStaker[idx].DAutoIncrement == dAutoIncrement && cacheTachEonTrendStaker[idx].DT1Mult == dT1Mult && cacheTachEonTrendStaker[idx].DT2Mult == dT2Mult && cacheTachEonTrendStaker[idx].DT3Mult == dT3Mult && cacheTachEonTrendStaker[idx].DT4Mult == dT4Mult && cacheTachEonTrendStaker[idx].DT5Mult == dT5Mult && cacheTachEonTrendStaker[idx].DT6Mult == dT6Mult && cacheTachEonTrendStaker[idx].BViewHistoricalTargets == bViewHistoricalTargets && cacheTachEonTrendStaker[idx].BViewCurrentTargets == bViewCurrentTargets && cacheTachEonTrendStaker[idx].BViewTargetLabels == bViewTargetLabels && cacheTachEonTrendStaker[idx].BArrowsOnReversal == bArrowsOnReversal && cacheTachEonTrendStaker[idx].BShowVerticalLine == bShowVerticalLine && cacheTachEonTrendStaker[idx].PVLineColor == pVLineColor && cacheTachEonTrendStaker[idx].PVLineStyle == pVLineStyle && cacheTachEonTrendStaker[idx].NVLineWidth == nVLineWidth && cacheTachEonTrendStaker[idx].bSearch == bSearch && cacheTachEonTrendStaker[idx].bMonday == bMonday && cacheTachEonTrendStaker[idx].bTuesday == bTuesday && cacheTachEonTrendStaker[idx].bWednesday == bWednesday && cacheTachEonTrendStaker[idx].bThursday == bThursday && cacheTachEonTrendStaker[idx].bFriday == bFriday && cacheTachEonTrendStaker[idx].EqualsInput(input))
						return cacheTachEonTrendStaker[idx];
			return CacheIndicator<TachEon.TachEonTrendStaker>(new TachEon.TachEonTrendStaker(){ SAggressiveTrendMode = sAggressiveTrendMode, NAgressivePeriod = nAgressivePeriod, DAggressiveMultiplier = dAggressiveMultiplier, NAggressiveSmoothingPeriod = nAggressiveSmoothingPeriod, SAggressiveTouchedWAV = sAggressiveTouchedWAV, SResumeTrendWAV = sResumeTrendWAV, STrendReversalDownWAV = sTrendReversalDownWAV, STrendstalkerReversalUpWAV = sTrendstalkerReversalUpWAV, STrendMode = sTrendMode, NPeriod = nPeriod, DMultiplier = dMultiplier, NSmoothingPeriod = nSmoothingPeriod, BRoundToTick = bRoundToTick, BColorBars = bColorBars, PUpColor = pUpColor, PDownColor = pDownColor, DAutoIncrement = dAutoIncrement, DT1Mult = dT1Mult, DT2Mult = dT2Mult, DT3Mult = dT3Mult, DT4Mult = dT4Mult, DT5Mult = dT5Mult, DT6Mult = dT6Mult, BViewHistoricalTargets = bViewHistoricalTargets, BViewCurrentTargets = bViewCurrentTargets, BViewTargetLabels = bViewTargetLabels, BArrowsOnReversal = bArrowsOnReversal, BShowVerticalLine = bShowVerticalLine, PVLineColor = pVLineColor, PVLineStyle = pVLineStyle, NVLineWidth = nVLineWidth, bSearch = bSearch, bMonday = bMonday, bTuesday = bTuesday, bWednesday = bWednesday, bThursday = bThursday, bFriday = bFriday }, input, ref cacheTachEonTrendStaker);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.TachEon.TachEonTrendStaker TachEonTrendStaker(string sAggressiveTrendMode, int nAgressivePeriod, double dAggressiveMultiplier, int nAggressiveSmoothingPeriod, string sAggressiveTouchedWAV, string sResumeTrendWAV, string sTrendReversalDownWAV, string sTrendstalkerReversalUpWAV, string sTrendMode, int nPeriod, double dMultiplier, int nSmoothingPeriod, bool bRoundToTick, bool bColorBars, Brush pUpColor, Brush pDownColor, double dAutoIncrement, double dT1Mult, double dT2Mult, double dT3Mult, double dT4Mult, double dT5Mult, double dT6Mult, bool bViewHistoricalTargets, bool bViewCurrentTargets, bool bViewTargetLabels, bool bArrowsOnReversal, bool bShowVerticalLine, Brush pVLineColor, DashStyleHelper pVLineStyle, int nVLineWidth, bool bSearch, bool bMonday, bool bTuesday, bool bWednesday, bool bThursday, bool bFriday)
		{
			return indicator.TachEonTrendStaker(Input, sAggressiveTrendMode, nAgressivePeriod, dAggressiveMultiplier, nAggressiveSmoothingPeriod, sAggressiveTouchedWAV, sResumeTrendWAV, sTrendReversalDownWAV, sTrendstalkerReversalUpWAV, sTrendMode, nPeriod, dMultiplier, nSmoothingPeriod, bRoundToTick, bColorBars, pUpColor, pDownColor, dAutoIncrement, dT1Mult, dT2Mult, dT3Mult, dT4Mult, dT5Mult, dT6Mult, bViewHistoricalTargets, bViewCurrentTargets, bViewTargetLabels, bArrowsOnReversal, bShowVerticalLine, pVLineColor, pVLineStyle, nVLineWidth, bSearch, bMonday, bTuesday, bWednesday, bThursday, bFriday);
		}


		
		public Indicators.TachEon.TachEonTrendStaker TachEonTrendStaker(ISeries<double> input , string sAggressiveTrendMode, int nAgressivePeriod, double dAggressiveMultiplier, int nAggressiveSmoothingPeriod, string sAggressiveTouchedWAV, string sResumeTrendWAV, string sTrendReversalDownWAV, string sTrendstalkerReversalUpWAV, string sTrendMode, int nPeriod, double dMultiplier, int nSmoothingPeriod, bool bRoundToTick, bool bColorBars, Brush pUpColor, Brush pDownColor, double dAutoIncrement, double dT1Mult, double dT2Mult, double dT3Mult, double dT4Mult, double dT5Mult, double dT6Mult, bool bViewHistoricalTargets, bool bViewCurrentTargets, bool bViewTargetLabels, bool bArrowsOnReversal, bool bShowVerticalLine, Brush pVLineColor, DashStyleHelper pVLineStyle, int nVLineWidth, bool bSearch, bool bMonday, bool bTuesday, bool bWednesday, bool bThursday, bool bFriday)
		{
			return indicator.TachEonTrendStaker(input, sAggressiveTrendMode, nAgressivePeriod, dAggressiveMultiplier, nAggressiveSmoothingPeriod, sAggressiveTouchedWAV, sResumeTrendWAV, sTrendReversalDownWAV, sTrendstalkerReversalUpWAV, sTrendMode, nPeriod, dMultiplier, nSmoothingPeriod, bRoundToTick, bColorBars, pUpColor, pDownColor, dAutoIncrement, dT1Mult, dT2Mult, dT3Mult, dT4Mult, dT5Mult, dT6Mult, bViewHistoricalTargets, bViewCurrentTargets, bViewTargetLabels, bArrowsOnReversal, bShowVerticalLine, pVLineColor, pVLineStyle, nVLineWidth, bSearch, bMonday, bTuesday, bWednesday, bThursday, bFriday);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.TachEon.TachEonTrendStaker TachEonTrendStaker(string sAggressiveTrendMode, int nAgressivePeriod, double dAggressiveMultiplier, int nAggressiveSmoothingPeriod, string sAggressiveTouchedWAV, string sResumeTrendWAV, string sTrendReversalDownWAV, string sTrendstalkerReversalUpWAV, string sTrendMode, int nPeriod, double dMultiplier, int nSmoothingPeriod, bool bRoundToTick, bool bColorBars, Brush pUpColor, Brush pDownColor, double dAutoIncrement, double dT1Mult, double dT2Mult, double dT3Mult, double dT4Mult, double dT5Mult, double dT6Mult, bool bViewHistoricalTargets, bool bViewCurrentTargets, bool bViewTargetLabels, bool bArrowsOnReversal, bool bShowVerticalLine, Brush pVLineColor, DashStyleHelper pVLineStyle, int nVLineWidth, bool bSearch, bool bMonday, bool bTuesday, bool bWednesday, bool bThursday, bool bFriday)
		{
			return indicator.TachEonTrendStaker(Input, sAggressiveTrendMode, nAgressivePeriod, dAggressiveMultiplier, nAggressiveSmoothingPeriod, sAggressiveTouchedWAV, sResumeTrendWAV, sTrendReversalDownWAV, sTrendstalkerReversalUpWAV, sTrendMode, nPeriod, dMultiplier, nSmoothingPeriod, bRoundToTick, bColorBars, pUpColor, pDownColor, dAutoIncrement, dT1Mult, dT2Mult, dT3Mult, dT4Mult, dT5Mult, dT6Mult, bViewHistoricalTargets, bViewCurrentTargets, bViewTargetLabels, bArrowsOnReversal, bShowVerticalLine, pVLineColor, pVLineStyle, nVLineWidth, bSearch, bMonday, bTuesday, bWednesday, bThursday, bFriday);
		}


		
		public Indicators.TachEon.TachEonTrendStaker TachEonTrendStaker(ISeries<double> input , string sAggressiveTrendMode, int nAgressivePeriod, double dAggressiveMultiplier, int nAggressiveSmoothingPeriod, string sAggressiveTouchedWAV, string sResumeTrendWAV, string sTrendReversalDownWAV, string sTrendstalkerReversalUpWAV, string sTrendMode, int nPeriod, double dMultiplier, int nSmoothingPeriod, bool bRoundToTick, bool bColorBars, Brush pUpColor, Brush pDownColor, double dAutoIncrement, double dT1Mult, double dT2Mult, double dT3Mult, double dT4Mult, double dT5Mult, double dT6Mult, bool bViewHistoricalTargets, bool bViewCurrentTargets, bool bViewTargetLabels, bool bArrowsOnReversal, bool bShowVerticalLine, Brush pVLineColor, DashStyleHelper pVLineStyle, int nVLineWidth, bool bSearch, bool bMonday, bool bTuesday, bool bWednesday, bool bThursday, bool bFriday)
		{
			return indicator.TachEonTrendStaker(input, sAggressiveTrendMode, nAgressivePeriod, dAggressiveMultiplier, nAggressiveSmoothingPeriod, sAggressiveTouchedWAV, sResumeTrendWAV, sTrendReversalDownWAV, sTrendstalkerReversalUpWAV, sTrendMode, nPeriod, dMultiplier, nSmoothingPeriod, bRoundToTick, bColorBars, pUpColor, pDownColor, dAutoIncrement, dT1Mult, dT2Mult, dT3Mult, dT4Mult, dT5Mult, dT6Mult, bViewHistoricalTargets, bViewCurrentTargets, bViewTargetLabels, bArrowsOnReversal, bShowVerticalLine, pVLineColor, pVLineStyle, nVLineWidth, bSearch, bMonday, bTuesday, bWednesday, bThursday, bFriday);
		}

	}
}

#endregion
