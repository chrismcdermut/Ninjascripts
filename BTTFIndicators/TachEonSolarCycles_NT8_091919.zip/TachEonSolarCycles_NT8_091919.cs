#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private TachEon.TachEonSolarCycles[] cacheTachEonSolarCycles;

		
		public TachEon.TachEonSolarCycles TachEonSolarCycles(int numberOfPastLevelsToLoad, int numberTimeSplits, int numberFutureTimeSplits, int startTimeSplitsFromCycle, Brush aColor, Brush aTColor, Brush aFTColor, DashStyleHelper aLineStyle, DashStyleHelper aTLineStyle, int aLineSize, eFluxSolarCyclesLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush pColor, Brush pTColor, Brush pFTColor, DashStyleHelper pLineStyle, DashStyleHelper pTLineStyle, int pLineSize, eFluxSolarCyclesLineLength pLineExtMethod, int pLineLength, int pDotOffset, TextPositionTachEonSC textLocation)
		{
			return TachEonSolarCycles(Input, numberOfPastLevelsToLoad, numberTimeSplits, numberFutureTimeSplits, startTimeSplitsFromCycle, aColor, aTColor, aFTColor, aLineStyle, aTLineStyle, aLineSize, aLineExtMethod, aLineLength, aDotOffset, pColor, pTColor, pFTColor, pLineStyle, pTLineStyle, pLineSize, pLineExtMethod, pLineLength, pDotOffset, textLocation);
		}


		
		public TachEon.TachEonSolarCycles TachEonSolarCycles(ISeries<double> input, int numberOfPastLevelsToLoad, int numberTimeSplits, int numberFutureTimeSplits, int startTimeSplitsFromCycle, Brush aColor, Brush aTColor, Brush aFTColor, DashStyleHelper aLineStyle, DashStyleHelper aTLineStyle, int aLineSize, eFluxSolarCyclesLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush pColor, Brush pTColor, Brush pFTColor, DashStyleHelper pLineStyle, DashStyleHelper pTLineStyle, int pLineSize, eFluxSolarCyclesLineLength pLineExtMethod, int pLineLength, int pDotOffset, TextPositionTachEonSC textLocation)
		{
			if (cacheTachEonSolarCycles != null)
				for (int idx = 0; idx < cacheTachEonSolarCycles.Length; idx++)
					if (cacheTachEonSolarCycles[idx].NumberOfPastLevelsToLoad == numberOfPastLevelsToLoad && cacheTachEonSolarCycles[idx].NumberTimeSplits == numberTimeSplits && cacheTachEonSolarCycles[idx].NumberFutureTimeSplits == numberFutureTimeSplits && cacheTachEonSolarCycles[idx].StartTimeSplitsFromCycle == startTimeSplitsFromCycle && cacheTachEonSolarCycles[idx].AColor == aColor && cacheTachEonSolarCycles[idx].ATColor == aTColor && cacheTachEonSolarCycles[idx].AFTColor == aFTColor && cacheTachEonSolarCycles[idx].ALineStyle == aLineStyle && cacheTachEonSolarCycles[idx].ATLineStyle == aTLineStyle && cacheTachEonSolarCycles[idx].ALineSize == aLineSize && cacheTachEonSolarCycles[idx].ALineExtMethod == aLineExtMethod && cacheTachEonSolarCycles[idx].ALineLength == aLineLength && cacheTachEonSolarCycles[idx].ADotOffset == aDotOffset && cacheTachEonSolarCycles[idx].PColor == pColor && cacheTachEonSolarCycles[idx].PTColor == pTColor && cacheTachEonSolarCycles[idx].PFTColor == pFTColor && cacheTachEonSolarCycles[idx].PLineStyle == pLineStyle && cacheTachEonSolarCycles[idx].PTLineStyle == pTLineStyle && cacheTachEonSolarCycles[idx].PLineSize == pLineSize && cacheTachEonSolarCycles[idx].PLineExtMethod == pLineExtMethod && cacheTachEonSolarCycles[idx].PLineLength == pLineLength && cacheTachEonSolarCycles[idx].PDotOffset == pDotOffset && cacheTachEonSolarCycles[idx].TextLocation == textLocation && cacheTachEonSolarCycles[idx].EqualsInput(input))
						return cacheTachEonSolarCycles[idx];
			return CacheIndicator<TachEon.TachEonSolarCycles>(new TachEon.TachEonSolarCycles(){ NumberOfPastLevelsToLoad = numberOfPastLevelsToLoad, NumberTimeSplits = numberTimeSplits, NumberFutureTimeSplits = numberFutureTimeSplits, StartTimeSplitsFromCycle = startTimeSplitsFromCycle, AColor = aColor, ATColor = aTColor, AFTColor = aFTColor, ALineStyle = aLineStyle, ATLineStyle = aTLineStyle, ALineSize = aLineSize, ALineExtMethod = aLineExtMethod, ALineLength = aLineLength, ADotOffset = aDotOffset, PColor = pColor, PTColor = pTColor, PFTColor = pFTColor, PLineStyle = pLineStyle, PTLineStyle = pTLineStyle, PLineSize = pLineSize, PLineExtMethod = pLineExtMethod, PLineLength = pLineLength, PDotOffset = pDotOffset, TextLocation = textLocation }, input, ref cacheTachEonSolarCycles);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.TachEon.TachEonSolarCycles TachEonSolarCycles(int numberOfPastLevelsToLoad, int numberTimeSplits, int numberFutureTimeSplits, int startTimeSplitsFromCycle, Brush aColor, Brush aTColor, Brush aFTColor, DashStyleHelper aLineStyle, DashStyleHelper aTLineStyle, int aLineSize, eFluxSolarCyclesLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush pColor, Brush pTColor, Brush pFTColor, DashStyleHelper pLineStyle, DashStyleHelper pTLineStyle, int pLineSize, eFluxSolarCyclesLineLength pLineExtMethod, int pLineLength, int pDotOffset, TextPositionTachEonSC textLocation)
		{
			return indicator.TachEonSolarCycles(Input, numberOfPastLevelsToLoad, numberTimeSplits, numberFutureTimeSplits, startTimeSplitsFromCycle, aColor, aTColor, aFTColor, aLineStyle, aTLineStyle, aLineSize, aLineExtMethod, aLineLength, aDotOffset, pColor, pTColor, pFTColor, pLineStyle, pTLineStyle, pLineSize, pLineExtMethod, pLineLength, pDotOffset, textLocation);
		}


		
		public Indicators.TachEon.TachEonSolarCycles TachEonSolarCycles(ISeries<double> input , int numberOfPastLevelsToLoad, int numberTimeSplits, int numberFutureTimeSplits, int startTimeSplitsFromCycle, Brush aColor, Brush aTColor, Brush aFTColor, DashStyleHelper aLineStyle, DashStyleHelper aTLineStyle, int aLineSize, eFluxSolarCyclesLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush pColor, Brush pTColor, Brush pFTColor, DashStyleHelper pLineStyle, DashStyleHelper pTLineStyle, int pLineSize, eFluxSolarCyclesLineLength pLineExtMethod, int pLineLength, int pDotOffset, TextPositionTachEonSC textLocation)
		{
			return indicator.TachEonSolarCycles(input, numberOfPastLevelsToLoad, numberTimeSplits, numberFutureTimeSplits, startTimeSplitsFromCycle, aColor, aTColor, aFTColor, aLineStyle, aTLineStyle, aLineSize, aLineExtMethod, aLineLength, aDotOffset, pColor, pTColor, pFTColor, pLineStyle, pTLineStyle, pLineSize, pLineExtMethod, pLineLength, pDotOffset, textLocation);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.TachEon.TachEonSolarCycles TachEonSolarCycles(int numberOfPastLevelsToLoad, int numberTimeSplits, int numberFutureTimeSplits, int startTimeSplitsFromCycle, Brush aColor, Brush aTColor, Brush aFTColor, DashStyleHelper aLineStyle, DashStyleHelper aTLineStyle, int aLineSize, eFluxSolarCyclesLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush pColor, Brush pTColor, Brush pFTColor, DashStyleHelper pLineStyle, DashStyleHelper pTLineStyle, int pLineSize, eFluxSolarCyclesLineLength pLineExtMethod, int pLineLength, int pDotOffset, TextPositionTachEonSC textLocation)
		{
			return indicator.TachEonSolarCycles(Input, numberOfPastLevelsToLoad, numberTimeSplits, numberFutureTimeSplits, startTimeSplitsFromCycle, aColor, aTColor, aFTColor, aLineStyle, aTLineStyle, aLineSize, aLineExtMethod, aLineLength, aDotOffset, pColor, pTColor, pFTColor, pLineStyle, pTLineStyle, pLineSize, pLineExtMethod, pLineLength, pDotOffset, textLocation);
		}


		
		public Indicators.TachEon.TachEonSolarCycles TachEonSolarCycles(ISeries<double> input , int numberOfPastLevelsToLoad, int numberTimeSplits, int numberFutureTimeSplits, int startTimeSplitsFromCycle, Brush aColor, Brush aTColor, Brush aFTColor, DashStyleHelper aLineStyle, DashStyleHelper aTLineStyle, int aLineSize, eFluxSolarCyclesLineLength aLineExtMethod, int aLineLength, int aDotOffset, Brush pColor, Brush pTColor, Brush pFTColor, DashStyleHelper pLineStyle, DashStyleHelper pTLineStyle, int pLineSize, eFluxSolarCyclesLineLength pLineExtMethod, int pLineLength, int pDotOffset, TextPositionTachEonSC textLocation)
		{
			return indicator.TachEonSolarCycles(input, numberOfPastLevelsToLoad, numberTimeSplits, numberFutureTimeSplits, startTimeSplitsFromCycle, aColor, aTColor, aFTColor, aLineStyle, aTLineStyle, aLineSize, aLineExtMethod, aLineLength, aDotOffset, pColor, pTColor, pFTColor, pLineStyle, pTLineStyle, pLineSize, pLineExtMethod, pLineLength, pDotOffset, textLocation);
		}

	}
}

#endregion
