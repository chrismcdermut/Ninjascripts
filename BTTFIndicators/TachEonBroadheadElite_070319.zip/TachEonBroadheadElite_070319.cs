#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private TachEon.TachEonBroadheadElite[] cacheTachEonBroadheadElite;

		
		public TachEon.TachEonBroadheadElite TachEonBroadheadElite(TachEonBroadheadElite_TargetsStopsType _toolType, int _aTRPeriod, double _minATR, int tick_Stop, double aTR_Stop, int tickSetting_Target1, int tickSetting_Target2, int tickSetting_Target3, double aTRSetting_Target1, double aTRSetting_Target2, double aTRSetting_Target3, string arrowWAV, bool enableSound, Brush upTrianglesColor, Brush downTrianglesColor, bool showTriangles, bool showArrows, bool showHistoricalSLandTP, bool useStandardArrows, bool usePlotTriangles, int customArrowSize, int separation, int upperThreshold, int lowerThreshold, TachEonBroadheadElite_FilterMAtype filterMAtype, int filterMAperiod, bool engageFilter)
		{
			return TachEonBroadheadElite(Input, _toolType, _aTRPeriod, _minATR, tick_Stop, aTR_Stop, tickSetting_Target1, tickSetting_Target2, tickSetting_Target3, aTRSetting_Target1, aTRSetting_Target2, aTRSetting_Target3, arrowWAV, enableSound, upTrianglesColor, downTrianglesColor, showTriangles, showArrows, showHistoricalSLandTP, useStandardArrows, usePlotTriangles, customArrowSize, separation, upperThreshold, lowerThreshold, filterMAtype, filterMAperiod, engageFilter);
		}


		
		public TachEon.TachEonBroadheadElite TachEonBroadheadElite(ISeries<double> input, TachEonBroadheadElite_TargetsStopsType _toolType, int _aTRPeriod, double _minATR, int tick_Stop, double aTR_Stop, int tickSetting_Target1, int tickSetting_Target2, int tickSetting_Target3, double aTRSetting_Target1, double aTRSetting_Target2, double aTRSetting_Target3, string arrowWAV, bool enableSound, Brush upTrianglesColor, Brush downTrianglesColor, bool showTriangles, bool showArrows, bool showHistoricalSLandTP, bool useStandardArrows, bool usePlotTriangles, int customArrowSize, int separation, int upperThreshold, int lowerThreshold, TachEonBroadheadElite_FilterMAtype filterMAtype, int filterMAperiod, bool engageFilter)
		{
			if (cacheTachEonBroadheadElite != null)
				for (int idx = 0; idx < cacheTachEonBroadheadElite.Length; idx++)
					if (cacheTachEonBroadheadElite[idx]._ToolType == _toolType && cacheTachEonBroadheadElite[idx]._ATRPeriod == _aTRPeriod && cacheTachEonBroadheadElite[idx]._MinATR == _minATR && cacheTachEonBroadheadElite[idx].Tick_Stop == tick_Stop && cacheTachEonBroadheadElite[idx].ATR_Stop == aTR_Stop && cacheTachEonBroadheadElite[idx].TickSetting_Target1 == tickSetting_Target1 && cacheTachEonBroadheadElite[idx].TickSetting_Target2 == tickSetting_Target2 && cacheTachEonBroadheadElite[idx].TickSetting_Target3 == tickSetting_Target3 && cacheTachEonBroadheadElite[idx].ATRSetting_Target1 == aTRSetting_Target1 && cacheTachEonBroadheadElite[idx].ATRSetting_Target2 == aTRSetting_Target2 && cacheTachEonBroadheadElite[idx].ATRSetting_Target3 == aTRSetting_Target3 && cacheTachEonBroadheadElite[idx].ArrowWAV == arrowWAV && cacheTachEonBroadheadElite[idx].EnableSound == enableSound && cacheTachEonBroadheadElite[idx].UpTrianglesColor == upTrianglesColor && cacheTachEonBroadheadElite[idx].DownTrianglesColor == downTrianglesColor && cacheTachEonBroadheadElite[idx].ShowTriangles == showTriangles && cacheTachEonBroadheadElite[idx].ShowArrows == showArrows && cacheTachEonBroadheadElite[idx].ShowHistoricalSLandTP == showHistoricalSLandTP && cacheTachEonBroadheadElite[idx].UseStandardArrows == useStandardArrows && cacheTachEonBroadheadElite[idx].UsePlotTriangles == usePlotTriangles && cacheTachEonBroadheadElite[idx].CustomArrowSize == customArrowSize && cacheTachEonBroadheadElite[idx].Separation == separation && cacheTachEonBroadheadElite[idx].UpperThreshold == upperThreshold && cacheTachEonBroadheadElite[idx].LowerThreshold == lowerThreshold && cacheTachEonBroadheadElite[idx].FilterMAtype == filterMAtype && cacheTachEonBroadheadElite[idx].FilterMAperiod == filterMAperiod && cacheTachEonBroadheadElite[idx].EngageFilter == engageFilter && cacheTachEonBroadheadElite[idx].EqualsInput(input))
						return cacheTachEonBroadheadElite[idx];
			return CacheIndicator<TachEon.TachEonBroadheadElite>(new TachEon.TachEonBroadheadElite(){ _ToolType = _toolType, _ATRPeriod = _aTRPeriod, _MinATR = _minATR, Tick_Stop = tick_Stop, ATR_Stop = aTR_Stop, TickSetting_Target1 = tickSetting_Target1, TickSetting_Target2 = tickSetting_Target2, TickSetting_Target3 = tickSetting_Target3, ATRSetting_Target1 = aTRSetting_Target1, ATRSetting_Target2 = aTRSetting_Target2, ATRSetting_Target3 = aTRSetting_Target3, ArrowWAV = arrowWAV, EnableSound = enableSound, UpTrianglesColor = upTrianglesColor, DownTrianglesColor = downTrianglesColor, ShowTriangles = showTriangles, ShowArrows = showArrows, ShowHistoricalSLandTP = showHistoricalSLandTP, UseStandardArrows = useStandardArrows, UsePlotTriangles = usePlotTriangles, CustomArrowSize = customArrowSize, Separation = separation, UpperThreshold = upperThreshold, LowerThreshold = lowerThreshold, FilterMAtype = filterMAtype, FilterMAperiod = filterMAperiod, EngageFilter = engageFilter }, input, ref cacheTachEonBroadheadElite);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.TachEon.TachEonBroadheadElite TachEonBroadheadElite(TachEonBroadheadElite_TargetsStopsType _toolType, int _aTRPeriod, double _minATR, int tick_Stop, double aTR_Stop, int tickSetting_Target1, int tickSetting_Target2, int tickSetting_Target3, double aTRSetting_Target1, double aTRSetting_Target2, double aTRSetting_Target3, string arrowWAV, bool enableSound, Brush upTrianglesColor, Brush downTrianglesColor, bool showTriangles, bool showArrows, bool showHistoricalSLandTP, bool useStandardArrows, bool usePlotTriangles, int customArrowSize, int separation, int upperThreshold, int lowerThreshold, TachEonBroadheadElite_FilterMAtype filterMAtype, int filterMAperiod, bool engageFilter)
		{
			return indicator.TachEonBroadheadElite(Input, _toolType, _aTRPeriod, _minATR, tick_Stop, aTR_Stop, tickSetting_Target1, tickSetting_Target2, tickSetting_Target3, aTRSetting_Target1, aTRSetting_Target2, aTRSetting_Target3, arrowWAV, enableSound, upTrianglesColor, downTrianglesColor, showTriangles, showArrows, showHistoricalSLandTP, useStandardArrows, usePlotTriangles, customArrowSize, separation, upperThreshold, lowerThreshold, filterMAtype, filterMAperiod, engageFilter);
		}


		
		public Indicators.TachEon.TachEonBroadheadElite TachEonBroadheadElite(ISeries<double> input , TachEonBroadheadElite_TargetsStopsType _toolType, int _aTRPeriod, double _minATR, int tick_Stop, double aTR_Stop, int tickSetting_Target1, int tickSetting_Target2, int tickSetting_Target3, double aTRSetting_Target1, double aTRSetting_Target2, double aTRSetting_Target3, string arrowWAV, bool enableSound, Brush upTrianglesColor, Brush downTrianglesColor, bool showTriangles, bool showArrows, bool showHistoricalSLandTP, bool useStandardArrows, bool usePlotTriangles, int customArrowSize, int separation, int upperThreshold, int lowerThreshold, TachEonBroadheadElite_FilterMAtype filterMAtype, int filterMAperiod, bool engageFilter)
		{
			return indicator.TachEonBroadheadElite(input, _toolType, _aTRPeriod, _minATR, tick_Stop, aTR_Stop, tickSetting_Target1, tickSetting_Target2, tickSetting_Target3, aTRSetting_Target1, aTRSetting_Target2, aTRSetting_Target3, arrowWAV, enableSound, upTrianglesColor, downTrianglesColor, showTriangles, showArrows, showHistoricalSLandTP, useStandardArrows, usePlotTriangles, customArrowSize, separation, upperThreshold, lowerThreshold, filterMAtype, filterMAperiod, engageFilter);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.TachEon.TachEonBroadheadElite TachEonBroadheadElite(TachEonBroadheadElite_TargetsStopsType _toolType, int _aTRPeriod, double _minATR, int tick_Stop, double aTR_Stop, int tickSetting_Target1, int tickSetting_Target2, int tickSetting_Target3, double aTRSetting_Target1, double aTRSetting_Target2, double aTRSetting_Target3, string arrowWAV, bool enableSound, Brush upTrianglesColor, Brush downTrianglesColor, bool showTriangles, bool showArrows, bool showHistoricalSLandTP, bool useStandardArrows, bool usePlotTriangles, int customArrowSize, int separation, int upperThreshold, int lowerThreshold, TachEonBroadheadElite_FilterMAtype filterMAtype, int filterMAperiod, bool engageFilter)
		{
			return indicator.TachEonBroadheadElite(Input, _toolType, _aTRPeriod, _minATR, tick_Stop, aTR_Stop, tickSetting_Target1, tickSetting_Target2, tickSetting_Target3, aTRSetting_Target1, aTRSetting_Target2, aTRSetting_Target3, arrowWAV, enableSound, upTrianglesColor, downTrianglesColor, showTriangles, showArrows, showHistoricalSLandTP, useStandardArrows, usePlotTriangles, customArrowSize, separation, upperThreshold, lowerThreshold, filterMAtype, filterMAperiod, engageFilter);
		}


		
		public Indicators.TachEon.TachEonBroadheadElite TachEonBroadheadElite(ISeries<double> input , TachEonBroadheadElite_TargetsStopsType _toolType, int _aTRPeriod, double _minATR, int tick_Stop, double aTR_Stop, int tickSetting_Target1, int tickSetting_Target2, int tickSetting_Target3, double aTRSetting_Target1, double aTRSetting_Target2, double aTRSetting_Target3, string arrowWAV, bool enableSound, Brush upTrianglesColor, Brush downTrianglesColor, bool showTriangles, bool showArrows, bool showHistoricalSLandTP, bool useStandardArrows, bool usePlotTriangles, int customArrowSize, int separation, int upperThreshold, int lowerThreshold, TachEonBroadheadElite_FilterMAtype filterMAtype, int filterMAperiod, bool engageFilter)
		{
			return indicator.TachEonBroadheadElite(input, _toolType, _aTRPeriod, _minATR, tick_Stop, aTR_Stop, tickSetting_Target1, tickSetting_Target2, tickSetting_Target3, aTRSetting_Target1, aTRSetting_Target2, aTRSetting_Target3, arrowWAV, enableSound, upTrianglesColor, downTrianglesColor, showTriangles, showArrows, showHistoricalSLandTP, useStandardArrows, usePlotTriangles, customArrowSize, separation, upperThreshold, lowerThreshold, filterMAtype, filterMAperiod, engageFilter);
		}

	}
}

#endregion
