#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private TachEon.FluxRapidFireFull[] cacheFluxRapidFireFull;
		private TachEon.FluxRapidFireHisto[] cacheFluxRapidFireHisto;

		
		public TachEon.FluxRapidFireFull FluxRapidFireFull(eFluxFapidFireFilterTypeFull fluxFapidFireFilterType, string accountName, int quantity, bool colorBars, bool hollowUpBars, Brush downIntoThresholdColor, Brush upIntoThresholdColor, Brush outsideColorUp, Brush outsideColorDown, Brush sellSignalColor, Brush buySignalColor, int buySignalBkgrndOpacity, int sellSignalBkgrndOpacity, int separation, Brush centerBandSlopeUpColor, Brush centerBandSlopeDnColor, int speed, double retrace, FluxRapidFireFull_MAType mATypeA, int speedSq, FluxRapidFireFull_FilterType filterType, FluxRapidFireFull_MAType filterMAtype, int filterMAperiod, bool engageFilter, double hi_Rev, double lo_Rev, int threshold)
		{
			return FluxRapidFireFull(Input, fluxFapidFireFilterType, accountName, quantity, colorBars, hollowUpBars, downIntoThresholdColor, upIntoThresholdColor, outsideColorUp, outsideColorDown, sellSignalColor, buySignalColor, buySignalBkgrndOpacity, sellSignalBkgrndOpacity, separation, centerBandSlopeUpColor, centerBandSlopeDnColor, speed, retrace, mATypeA, speedSq, filterType, filterMAtype, filterMAperiod, engageFilter, hi_Rev, lo_Rev, threshold);
		}

		public TachEon.FluxRapidFireHisto FluxRapidFireHisto(int period, int percent)
		{
			return FluxRapidFireHisto(Input, period, percent);
		}


		
		public TachEon.FluxRapidFireFull FluxRapidFireFull(ISeries<double> input, eFluxFapidFireFilterTypeFull fluxFapidFireFilterType, string accountName, int quantity, bool colorBars, bool hollowUpBars, Brush downIntoThresholdColor, Brush upIntoThresholdColor, Brush outsideColorUp, Brush outsideColorDown, Brush sellSignalColor, Brush buySignalColor, int buySignalBkgrndOpacity, int sellSignalBkgrndOpacity, int separation, Brush centerBandSlopeUpColor, Brush centerBandSlopeDnColor, int speed, double retrace, FluxRapidFireFull_MAType mATypeA, int speedSq, FluxRapidFireFull_FilterType filterType, FluxRapidFireFull_MAType filterMAtype, int filterMAperiod, bool engageFilter, double hi_Rev, double lo_Rev, int threshold)
		{
			if (cacheFluxRapidFireFull != null)
				for (int idx = 0; idx < cacheFluxRapidFireFull.Length; idx++)
					if (cacheFluxRapidFireFull[idx].FluxFapidFireFilterType == fluxFapidFireFilterType && cacheFluxRapidFireFull[idx].AccountName == accountName && cacheFluxRapidFireFull[idx].Quantity == quantity && cacheFluxRapidFireFull[idx].ColorBars == colorBars && cacheFluxRapidFireFull[idx].HollowUpBars == hollowUpBars && cacheFluxRapidFireFull[idx].DownIntoThresholdColor == downIntoThresholdColor && cacheFluxRapidFireFull[idx].UpIntoThresholdColor == upIntoThresholdColor && cacheFluxRapidFireFull[idx].OutsideColorUp == outsideColorUp && cacheFluxRapidFireFull[idx].OutsideColorDown == outsideColorDown && cacheFluxRapidFireFull[idx].SellSignalColor == sellSignalColor && cacheFluxRapidFireFull[idx].BuySignalColor == buySignalColor && cacheFluxRapidFireFull[idx].BuySignalBkgrndOpacity == buySignalBkgrndOpacity && cacheFluxRapidFireFull[idx].SellSignalBkgrndOpacity == sellSignalBkgrndOpacity && cacheFluxRapidFireFull[idx].Separation == separation && cacheFluxRapidFireFull[idx].CenterBandSlopeUpColor == centerBandSlopeUpColor && cacheFluxRapidFireFull[idx].CenterBandSlopeDnColor == centerBandSlopeDnColor && cacheFluxRapidFireFull[idx].Speed == speed && cacheFluxRapidFireFull[idx].Retrace == retrace && cacheFluxRapidFireFull[idx].MATypeA == mATypeA && cacheFluxRapidFireFull[idx].SpeedSq == speedSq && cacheFluxRapidFireFull[idx].FilterType == filterType && cacheFluxRapidFireFull[idx].FilterMAtype == filterMAtype && cacheFluxRapidFireFull[idx].FilterMAperiod == filterMAperiod && cacheFluxRapidFireFull[idx].EngageFilter == engageFilter && cacheFluxRapidFireFull[idx].Hi_Rev == hi_Rev && cacheFluxRapidFireFull[idx].Lo_Rev == lo_Rev && cacheFluxRapidFireFull[idx].Threshold == threshold && cacheFluxRapidFireFull[idx].EqualsInput(input))
						return cacheFluxRapidFireFull[idx];
			return CacheIndicator<TachEon.FluxRapidFireFull>(new TachEon.FluxRapidFireFull(){ FluxFapidFireFilterType = fluxFapidFireFilterType, AccountName = accountName, Quantity = quantity, ColorBars = colorBars, HollowUpBars = hollowUpBars, DownIntoThresholdColor = downIntoThresholdColor, UpIntoThresholdColor = upIntoThresholdColor, OutsideColorUp = outsideColorUp, OutsideColorDown = outsideColorDown, SellSignalColor = sellSignalColor, BuySignalColor = buySignalColor, BuySignalBkgrndOpacity = buySignalBkgrndOpacity, SellSignalBkgrndOpacity = sellSignalBkgrndOpacity, Separation = separation, CenterBandSlopeUpColor = centerBandSlopeUpColor, CenterBandSlopeDnColor = centerBandSlopeDnColor, Speed = speed, Retrace = retrace, MATypeA = mATypeA, SpeedSq = speedSq, FilterType = filterType, FilterMAtype = filterMAtype, FilterMAperiod = filterMAperiod, EngageFilter = engageFilter, Hi_Rev = hi_Rev, Lo_Rev = lo_Rev, Threshold = threshold }, input, ref cacheFluxRapidFireFull);
		}

		public TachEon.FluxRapidFireHisto FluxRapidFireHisto(ISeries<double> input, int period, int percent)
		{
			if (cacheFluxRapidFireHisto != null)
				for (int idx = 0; idx < cacheFluxRapidFireHisto.Length; idx++)
					if (cacheFluxRapidFireHisto[idx].Period == period && cacheFluxRapidFireHisto[idx].Percent == percent && cacheFluxRapidFireHisto[idx].EqualsInput(input))
						return cacheFluxRapidFireHisto[idx];
			return CacheIndicator<TachEon.FluxRapidFireHisto>(new TachEon.FluxRapidFireHisto(){ Period = period, Percent = percent }, input, ref cacheFluxRapidFireHisto);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.TachEon.FluxRapidFireFull FluxRapidFireFull(eFluxFapidFireFilterTypeFull fluxFapidFireFilterType, string accountName, int quantity, bool colorBars, bool hollowUpBars, Brush downIntoThresholdColor, Brush upIntoThresholdColor, Brush outsideColorUp, Brush outsideColorDown, Brush sellSignalColor, Brush buySignalColor, int buySignalBkgrndOpacity, int sellSignalBkgrndOpacity, int separation, Brush centerBandSlopeUpColor, Brush centerBandSlopeDnColor, int speed, double retrace, FluxRapidFireFull_MAType mATypeA, int speedSq, FluxRapidFireFull_FilterType filterType, FluxRapidFireFull_MAType filterMAtype, int filterMAperiod, bool engageFilter, double hi_Rev, double lo_Rev, int threshold)
		{
			return indicator.FluxRapidFireFull(Input, fluxFapidFireFilterType, accountName, quantity, colorBars, hollowUpBars, downIntoThresholdColor, upIntoThresholdColor, outsideColorUp, outsideColorDown, sellSignalColor, buySignalColor, buySignalBkgrndOpacity, sellSignalBkgrndOpacity, separation, centerBandSlopeUpColor, centerBandSlopeDnColor, speed, retrace, mATypeA, speedSq, filterType, filterMAtype, filterMAperiod, engageFilter, hi_Rev, lo_Rev, threshold);
		}

		public Indicators.TachEon.FluxRapidFireHisto FluxRapidFireHisto(int period, int percent)
		{
			return indicator.FluxRapidFireHisto(Input, period, percent);
		}


		
		public Indicators.TachEon.FluxRapidFireFull FluxRapidFireFull(ISeries<double> input , eFluxFapidFireFilterTypeFull fluxFapidFireFilterType, string accountName, int quantity, bool colorBars, bool hollowUpBars, Brush downIntoThresholdColor, Brush upIntoThresholdColor, Brush outsideColorUp, Brush outsideColorDown, Brush sellSignalColor, Brush buySignalColor, int buySignalBkgrndOpacity, int sellSignalBkgrndOpacity, int separation, Brush centerBandSlopeUpColor, Brush centerBandSlopeDnColor, int speed, double retrace, FluxRapidFireFull_MAType mATypeA, int speedSq, FluxRapidFireFull_FilterType filterType, FluxRapidFireFull_MAType filterMAtype, int filterMAperiod, bool engageFilter, double hi_Rev, double lo_Rev, int threshold)
		{
			return indicator.FluxRapidFireFull(input, fluxFapidFireFilterType, accountName, quantity, colorBars, hollowUpBars, downIntoThresholdColor, upIntoThresholdColor, outsideColorUp, outsideColorDown, sellSignalColor, buySignalColor, buySignalBkgrndOpacity, sellSignalBkgrndOpacity, separation, centerBandSlopeUpColor, centerBandSlopeDnColor, speed, retrace, mATypeA, speedSq, filterType, filterMAtype, filterMAperiod, engageFilter, hi_Rev, lo_Rev, threshold);
		}

		public Indicators.TachEon.FluxRapidFireHisto FluxRapidFireHisto(ISeries<double> input , int period, int percent)
		{
			return indicator.FluxRapidFireHisto(input, period, percent);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.TachEon.FluxRapidFireFull FluxRapidFireFull(eFluxFapidFireFilterTypeFull fluxFapidFireFilterType, string accountName, int quantity, bool colorBars, bool hollowUpBars, Brush downIntoThresholdColor, Brush upIntoThresholdColor, Brush outsideColorUp, Brush outsideColorDown, Brush sellSignalColor, Brush buySignalColor, int buySignalBkgrndOpacity, int sellSignalBkgrndOpacity, int separation, Brush centerBandSlopeUpColor, Brush centerBandSlopeDnColor, int speed, double retrace, FluxRapidFireFull_MAType mATypeA, int speedSq, FluxRapidFireFull_FilterType filterType, FluxRapidFireFull_MAType filterMAtype, int filterMAperiod, bool engageFilter, double hi_Rev, double lo_Rev, int threshold)
		{
			return indicator.FluxRapidFireFull(Input, fluxFapidFireFilterType, accountName, quantity, colorBars, hollowUpBars, downIntoThresholdColor, upIntoThresholdColor, outsideColorUp, outsideColorDown, sellSignalColor, buySignalColor, buySignalBkgrndOpacity, sellSignalBkgrndOpacity, separation, centerBandSlopeUpColor, centerBandSlopeDnColor, speed, retrace, mATypeA, speedSq, filterType, filterMAtype, filterMAperiod, engageFilter, hi_Rev, lo_Rev, threshold);
		}

		public Indicators.TachEon.FluxRapidFireHisto FluxRapidFireHisto(int period, int percent)
		{
			return indicator.FluxRapidFireHisto(Input, period, percent);
		}


		
		public Indicators.TachEon.FluxRapidFireFull FluxRapidFireFull(ISeries<double> input , eFluxFapidFireFilterTypeFull fluxFapidFireFilterType, string accountName, int quantity, bool colorBars, bool hollowUpBars, Brush downIntoThresholdColor, Brush upIntoThresholdColor, Brush outsideColorUp, Brush outsideColorDown, Brush sellSignalColor, Brush buySignalColor, int buySignalBkgrndOpacity, int sellSignalBkgrndOpacity, int separation, Brush centerBandSlopeUpColor, Brush centerBandSlopeDnColor, int speed, double retrace, FluxRapidFireFull_MAType mATypeA, int speedSq, FluxRapidFireFull_FilterType filterType, FluxRapidFireFull_MAType filterMAtype, int filterMAperiod, bool engageFilter, double hi_Rev, double lo_Rev, int threshold)
		{
			return indicator.FluxRapidFireFull(input, fluxFapidFireFilterType, accountName, quantity, colorBars, hollowUpBars, downIntoThresholdColor, upIntoThresholdColor, outsideColorUp, outsideColorDown, sellSignalColor, buySignalColor, buySignalBkgrndOpacity, sellSignalBkgrndOpacity, separation, centerBandSlopeUpColor, centerBandSlopeDnColor, speed, retrace, mATypeA, speedSq, filterType, filterMAtype, filterMAperiod, engageFilter, hi_Rev, lo_Rev, threshold);
		}

		public Indicators.TachEon.FluxRapidFireHisto FluxRapidFireHisto(ISeries<double> input , int period, int percent)
		{
			return indicator.FluxRapidFireHisto(input, period, percent);
		}

	}
}

#endregion
